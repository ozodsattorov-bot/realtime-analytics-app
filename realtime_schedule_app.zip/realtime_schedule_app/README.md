Haftalik Jadval — Lokal saqlovchi veb-ilova
===========================================
Bu kichik web ilova localStorage orqali haftalik vazifalarni qo'shish, tahrirlash, qidirish va o'chirish imkonini beradi.

Fayllar:
- index.html
- style.css
- script.js

Ishga tushirish:
1. Papkani oching va brauzerda `index.html` faylini oching.
2. Yoki oddiy HTTP serverdan foydalaning:
   python3 -m http.server 8000
   keyin brauzerda http://localhost:8000 ga o'ting.

ZIP faylni yuklab olish havolasi shu papkada mavjud.
