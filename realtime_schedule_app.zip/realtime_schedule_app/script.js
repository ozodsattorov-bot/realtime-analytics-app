// Simple schedule app using localStorage
const KEY = 'weekly_schedule_v1';
let items = JSON.parse(localStorage.getItem(KEY) || '[]');

const dayEl = document.getElementById('day');
const timeEl = document.getElementById('time');
const titleEl = document.getElementById('title');
const noteEl = document.getElementById('note');
const addBtn = document.getElementById('addBtn');
const listEl = document.getElementById('list');
const tpl = document.getElementById('itemTpl');
const searchEl = document.getElementById('search');
const filterDay = document.getElementById('filterDay');
const clearAllBtn = document.getElementById('clearAll');

function save(){
  localStorage.setItem(KEY, JSON.stringify(items));
  render();
}

function addItem(){
  const obj = {
    id: Date.now(),
    day: dayEl.value,
    time: timeEl.value || '',
    title: (titleEl.value || '').trim(),
    note: (noteEl.value || '').trim()
  };
  if(!obj.title){ alert('Iltimos, vazifa nomini kiriting.'); return; }
  items.push(obj);
  // sort by day order then time
  const order = ['Dushanba','Seshanba','Chorshanba','Payshanba','Juma','Shanba','Yakshanba'];
  items.sort((a,b)=>{
    const da = order.indexOf(a.day), db = order.indexOf(b.day);
    if(da!==db) return da-db;
    return (a.time||'') > (b.time||'') ? 1 : -1;
  });
  titleEl.value=''; noteEl.value=''; timeEl.value='';
  save();
}

function render(){
  listEl.innerHTML='';
  const q = (searchEl.value||'').toLowerCase();
  const fd = filterDay.value;
  items.forEach(it=>{
    if(fd && it.day!==fd) return;
    const text = (it.day+' '+it.title+' '+it.note+' '+it.time).toLowerCase();
    if(q && !text.includes(q)) return;
    const node = tpl.content.cloneNode(true);
    node.querySelector('.day').textContent = it.day;
    node.querySelector('.time').textContent = it.time;
    node.querySelector('.title').textContent = it.title;
    node.querySelector('.note').textContent = it.note;
    const editBtn = node.querySelector('.edit');
    const delBtn = node.querySelector('.del');
    editBtn.onclick = ()=> editItem(it.id);
    delBtn.onclick = ()=> { if(confirm('O'chirishni xohlaysizmi?')){ items = items.filter(x=>x.id!==it.id); save(); } };
    listEl.appendChild(node);
  });
}

function editItem(id){
  const it = items.find(x=>x.id===id);
  if(!it) return;
  const newTitle = prompt('Yangi nom:', it.title);
  if(newTitle===null) return;
  const newNote = prompt('Yangi izoh:', it.note || '');
  it.title = newTitle.trim() || it.title;
  it.note = newNote.trim();
  save();
}

addBtn.addEventListener('click', addItem);
searchEl.addEventListener('input', render);
filterDay.addEventListener('change', render);
clearAllBtn.addEventListener('click', ()=>{
  if(confirm('Hamma yozuvlarni o'chirishni xohlaysizmi?')){ items=[]; save(); }
});

render();
